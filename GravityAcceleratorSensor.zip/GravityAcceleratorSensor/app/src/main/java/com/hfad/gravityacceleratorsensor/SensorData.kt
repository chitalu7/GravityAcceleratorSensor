package com.hfad.gravityacceleratorsensor

data class SensorData(var x1:Float, var x2:Float, var x3:Float, var timestamp: Long) {
}